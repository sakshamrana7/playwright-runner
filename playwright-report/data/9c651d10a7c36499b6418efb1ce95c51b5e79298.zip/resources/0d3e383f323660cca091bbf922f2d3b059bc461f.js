(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/components_10dpvn7._.js","static/chunks/node_modules_next_08vd8r7._.js","static/chunks/node_modules_motion-dom_dist_es_0n_wqqr._.js","static/chunks/node_modules_framer-motion_dist_es_129u8xh._.js","static/chunks/node_modules_zod_v3_0d-62mx._.js","static/chunks/node_modules_micromark-core-commonmark_dev_lib_13dj~6i._.js","static/chunks/node_modules_07x03c-._.js"],
    source: "dynamic"
});
